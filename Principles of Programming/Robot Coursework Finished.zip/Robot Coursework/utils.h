#ifndef UTILS_H
#define UTILS_H

// Define the size of the window that opens.
#define WIN_WIDTH 1400
#define WIN_HEIGHT 800

#endif /* UTILS_H */
